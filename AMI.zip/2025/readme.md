**AMI** is an intelligent matchmaking assistant that uses OpenAI's ChatGPT's api to create conversation with users.
It helps users find connections that they can relate to.

Clients connect to a central server and register using a unique id.
Conversations happen through a self-written messaging protocol.
We built a custom database in order to store the user's profile and match them by their personality traits.

When a match is found, it transitions the user from chatting with AI to a real person who fits their profile.
